int default_thread_count(void);
