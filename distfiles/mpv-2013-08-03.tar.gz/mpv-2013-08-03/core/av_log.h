void init_libav(void);
void print_libav_versions(void);
